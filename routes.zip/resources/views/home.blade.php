<x-layouts.app>
    <x-slot name="title">
        Catálogo de Produtos
    </x-slot>

    @livewire('product-search')

</x-layouts.app>