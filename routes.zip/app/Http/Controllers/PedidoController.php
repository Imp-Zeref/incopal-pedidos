<?php

namespace App\Http\Controllers;

use App\Models\Pedido;
use App\Models\Produto;
use App\Models\StatusPedido;
use App\Models\StatusProdutoPedido;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

class PedidoController extends Controller
{
    /**
     * Exibe a lista de pedidos.
     * Mostra todos os pedidos para o Admin, ou apenas os do usuário logado.
     */
    public function index(Request $request)
    {
        $usuario = $request->user();
        $query = Pedido::query();

        if ($usuario->tipoUsuario->nome !== 'Administrador') {
            $query->where('fk_usuario', $usuario->id);
        }

        $pedidos = $query->with(['statusPedido', 'cliente', 'tipoPedido', 'usuario'])
                         ->latest()
                         ->paginate(15);

        return view('pedidos.index', compact('pedidos'));
    }

    /**
     * Exibe os detalhes de um pedido específico.
     */
    public function show(Pedido $pedido)
    {
        Gate::authorize('view', $pedido);

        $pedido->load('usuario', 'cliente', 'statusPedido', 'tipoPedido', 'produtos.statusProduto');
        
        $produtosDisponiveis = Produto::orderBy('nome')->get();
        $statusDisponiveis = StatusPedido::whereIn('nome', ['Encomendado', 'Concluído', 'Não Cotado'])->get();

        return view('pedidos.show', compact('pedido', 'produtosDisponiveis', 'statusDisponiveis'));
    }

    /**
     * Exibe o formulário para editar um pedido (função a ser implementada).
     */
    public function edit(Pedido $pedido)
    {
        // A lógica para o formulário de edição virá aqui no futuro.
        Gate::authorize('update', $pedido);
    }
    
    /**
     * Atualiza os dados de um pedido existente (função a ser implementada).
     */
    public function update(Request $request, Pedido $pedido)
    {
        // A lógica para salvar as edições virá aqui no futuro.
        Gate::authorize('update', $pedido);
    }

    public function addProduct(Request $request, Pedido $pedido)
    {
        Gate::authorize('addProduct', $pedido);

        $dadosValidados = $request->validate([
            'produto_id' => 'required|exists:produtos,id',
            'quantidade' => 'required|numeric|min:0.01',
        ]);

        $statusPendente = StatusProdutoPedido::where('nome', 'Pendente')->firstOrFail();

        $pedido->produtos()->attach($dadosValidados['produto_id'], [
            'quantidade' => $dadosValidados['quantidade'],
            'fk_status_produto' => $statusPendente->id
        ]);

        return redirect()->route('pedidos.show', $pedido)->with('sucesso', 'Produto adicionado com sucesso!');
    }

    public function updateStatus(Request $request, Pedido $pedido)
    {
        Gate::authorize('changeStatus', $pedido);

        $dadosValidados = $request->validate(['fk_status_pedido' => 'required|exists:status_pedidos,id']);
        $pedido->update($dadosValidados);

        return redirect()->route('pedidos.show', $pedido)->with('sucesso', 'Status do pedido atualizado!');
    }

    public function cancel(Request $request, Pedido $pedido)
    {
        Gate::authorize('cancel', $pedido);

        $statusCancelado = StatusPedido::where('nome', 'Cancelado')->firstOrFail();
        $pedido->update(['fk_status_pedido' => $statusCancelado->id]);

        return redirect()->route('pedidos.show', $pedido)->with('sucesso', 'Pedido cancelado com sucesso.');
    }
}